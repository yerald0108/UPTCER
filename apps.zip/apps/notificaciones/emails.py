from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings


def enviar_correo_notificacion(
        usuario,
        titulo,
        mensaje,
        solicitud=None,
        template="emails/notificacion_usuario.html"
):

    if not usuario.email:
        return

    contexto = {
        "usuario": usuario,
        "titulo": titulo,
        "mensaje": mensaje,
        "solicitud": solicitud,
    }

    html = render_to_string(template, contexto)

    email = EmailMultiAlternatives(
        subject=titulo,
        body=mensaje,
        from_email=settings.DEFAULT_FROM_EMAIL,
        to=[usuario.email],
    )

    email.attach_alternative(html, "text/html")
    email.send(fail_silently=True)